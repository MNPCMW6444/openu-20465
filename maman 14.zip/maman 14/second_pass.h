#ifndef SECOND_PASS
#define SECOND_PASS

#include "commands.h"
#include "data_handler.h"
#include "symbol_table.h"
#include "util.h"

bool secondPass(char* file_name);

#endif
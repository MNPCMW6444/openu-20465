#ifndef MACRO_UNFOLD
#define MACRO_UNFOLD

#include "util.h"
#include "macro_table.h"
#include "globals.h"

bool pre_processor_func(char* file_name);

#endif
#ifndef FIRST_PASS
#define FIRST_PASS

#include "commands.h"
#include "data_handler.h"
#include "symbol_table.h"
#include "util.h"

bool do_first_pass(char* file_name);

#endif